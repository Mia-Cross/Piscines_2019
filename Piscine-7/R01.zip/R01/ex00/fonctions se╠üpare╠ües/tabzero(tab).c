void		tabzero(int *tab)
{
	tab[0] = 0;
	tab[1] = 0;
	tab[2] = 0;
	tab[3] = 0;
	tab[4] = 0;
	tab[5] = 0;
	tab[6] = 0;
	tab[7] = 0;
	tab[8] = 0;
	tab[9] = 0;
	tab[10] = 0;
	tab[11] = 0;
	tab[12] = 0;
	tab[13] = 0;
	tab[14] = 0;
	tab[15] = 0;
}
