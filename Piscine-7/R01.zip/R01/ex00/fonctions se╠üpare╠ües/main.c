int			main(int ac, char **av)
{
	int tab[16];
	int cote[16];

	if (ac != 2)
		return (print_error());
	if (!(fill_param(av[1], cote)))
		return (print_error());
	tabzero(tab);
	if (ft_fill(tab, cote, 0))
	{
		print_solution(tab);
	}
	else
	{
		print_error();
	}
	return (0);
}
