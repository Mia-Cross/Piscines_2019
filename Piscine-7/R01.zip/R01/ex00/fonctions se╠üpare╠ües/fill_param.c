int			fill_param(char *str, int *cote)
{
	int x;

	x = 0;
	while (str[x])
	{
		if (x % 2)
		{
			if (str[x] != ' ')
				return (0);
		}
		else
		{
			if (str[x] < '1' || str[x] > '4')
				return (0);
			cote[x / 2] = str[x] - '0';
		}
		x++;
	}
	if (x != 31)
		return (0);
	return (1);
}
