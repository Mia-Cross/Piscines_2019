int			ft_base(int *tab, int *param)
{
	int i;
	int x;

	x = 0;
	i = 0;
	while (param[i] == 4 && x < 4)
	{
		tab[x] = i + 1;
		x++;
	}
	x = 0;
	while (param[i] == 1 && x < 4)
	{
		tab[x] = i + 1;
		x++;
	}
	return (0);
}
