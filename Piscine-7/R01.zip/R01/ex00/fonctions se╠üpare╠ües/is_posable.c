int			isposable(int *tab, int pos, int i)
{
	int x;
	int y;
	int p;

	x = pos % 4;
	y = pos / 4;
	p = 0;
	while (p < 4)
	{
		if (tab[p + y * 4] == i)
			return (0);
		p++;
	}
	p = 0;
	while (p < 4)
	{
		if (tab[x + p * 4] == i)
			return (0);
		p++;
	}
	return (1);
}
