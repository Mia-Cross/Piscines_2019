void		ft_putchar(char c)
{
	write(1, &c, 1);
}

void		print_solution(int *tab)
{
	int x;
	int y;

	y = 0;
	while (y < 4)
	{
		x = 0;
		while (x < 4)
		{
			ft_putchar(tab[x + y * 4] + '0');
			if (x != 3)
				ft_putchar(' ');
			x++;
		}
		ft_putchar('\n');
		y++;
	}
}

int			print_error(void)
{
	write(1, "Error\n", 6);
	return (0);
}
