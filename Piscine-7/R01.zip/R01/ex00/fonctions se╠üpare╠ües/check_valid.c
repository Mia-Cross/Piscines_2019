int			check_valid(int *tab, int *cote)
{
	int x;

	x = -1;
	while (++x < 4)
		if (check_up(tab, cote[x], x))
			return (0);
	while (++x < 8)
		if (check_down(tab, cote[x], x + 8))
			return (0);
	while (++x < 12)
		if (check_left(tab, cote[x], (x - 8) * 4))
			return (0);
	if (check_right(tab, cote[12], 3))
		return (0);
	if (check_right(tab, cote[13], 7))
		return (0);
	if (check_right(tab, cote[14], 11))
		return (0);
	if (check_right(tab, cote[15], 15))
		return (0);
	return (1);
}
