int			ft_fill(int *tab, int *cote, int pos)
{
	int i;

	if (pos == 16)
	{
		if (check_valid(tab, cote))
			return (1);
		return (0);
	}
	if (tab[pos])
	{
		if (ft_fill(tab, cote, pos + 1))
			return (1);
		return (0);
	}
	i = 0;
	while (++i <= 4)
		if (isposable(tab, pos, i))
		{
			tab[pos] = i;
			if (ft_fill(tab, cote, pos + 1))
				return (1);
			tab[pos] = 0;
		}
	return (0);
}
