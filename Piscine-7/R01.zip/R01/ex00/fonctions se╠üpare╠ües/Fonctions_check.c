int			check_left(int *tab, int num, int pos)
{
	int check;
	int x;

	check = 0;
	x = pos;
	while (x < pos + 4)
	{
		if (check < tab[x])
		{
			check = tab[x];
			num--;
		}
		x++;
	}
	return (num);
}

int			check_right(int *tab, int num, int pos)
{
	int check;
	int x;

	check = 0;
	x = pos;
	while (x > pos - 4)
	{
		if (check < tab[x])
		{
			check = tab[x];
			num--;
		}
		x--;
	}
	return (num);
}

int			check_down(int *tab, int num, int pos)
{
	int check;
	int x;

	check = 0;
	x = pos;
	while (x >= pos - 12)
	{
		if (check < tab[x])
		{
			check = tab[x];
			num--;
		}
		x -= 4;
	}
	return (num);
}

int			check_up(int *tab, int num, int pos)
{
	int check;
	int x;

	check = 0;
	x = pos;
	while (x <= pos + 12)
	{
		if (check < tab[x])
		{
			check = tab[x];
			num--;
		}
		x += 4;
	}
	return (num);
}
